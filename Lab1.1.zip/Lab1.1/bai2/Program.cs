﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Nhập chieu dai: ");
        double dai = double.Parse(Console.ReadLine());

        Console.Write("Nhập chieu rong: ");
        double rong = double.Parse(Console.ReadLine());

        double dientich = dai * rong;
        Console.WriteLine("Dien tich HCN la: " + dientich);
    }
}

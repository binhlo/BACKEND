﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Nhap so bat ky: ");
        int so = int.Parse(Console.ReadLine());

        if (so % 2 == 0)
            Console.WriteLine(so + " la so chan");
        else
            Console.WriteLine(so + " la so le");
    }
}

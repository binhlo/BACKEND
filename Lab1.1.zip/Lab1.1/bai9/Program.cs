﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Nhap so duong n: ");
        int n = int.Parse(Console.ReadLine());
        long gt = 1;

        for (int i = 1; i <= n; i++)
        {
            gt *= i;
        }

        Console.WriteLine($"{n}! = {gt}");
    }
}
﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Nhap so thu nhat: ");
        double a = double.Parse(Console.ReadLine());

        Console.Write("Nhap so thu hai: ");
        double b = double.Parse(Console.ReadLine());

        double tong = a + b;
        double tich = a * b;

        Console.WriteLine("Tong: " + tong);
        Console.WriteLine("Tich: " + tich);
    }
}

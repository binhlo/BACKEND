﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Nhap ten: ");
        string ten = Console.ReadLine();

        Console.Write("Nhap tuoi: ");
        int tuoi = int.Parse(Console.ReadLine());

        Console.WriteLine($"Xin chao {ten}, ban {tuoi} tuoi");
    }
}

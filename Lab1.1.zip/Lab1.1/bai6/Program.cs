﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Nhap mot so: ");
        double so = double.Parse(Console.ReadLine());

        if (so > 0)
            Console.WriteLine("So duong");
        else if (so < 0)
            Console.WriteLine("So am");
        else
            Console.WriteLine("So khong");
    }
}

﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Nhap do C: ");
        double c = double.Parse(Console.ReadLine());

        double f = (c * 9 / 5) + 32;
        Console.WriteLine("Nhiet do F la: " + f);
    }
}
